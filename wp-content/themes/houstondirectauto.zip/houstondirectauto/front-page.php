<?php
/**
 *Template Name:Home-page
 * The main template file
 *
 */

get_header(); ?>
<div class="home-wrap">
  <section class="introduction" id="introduction">
    <div class="wrapper notification__attached">
      <section id="fetch-form" itemscope itemtype="http://schema.org/Website">
        <meta itemprop="url" content="http://www.texasdirectauto.com">
        <div class="tda-search">
          <ul id="tags">
            <li class="tag">
              <span class="tag-display" placeholder="Search here... (e.g., Red SUV, Payment $400, or black convertible)" contenteditable="false"></span>
            </li>
          </ul>
          <button class="tda-search__button"><i class="icon-search"></i></button>
        </div>
      </section>
      <section id="quick-search">
        
        <h1>2694 rides ready to roll</h1>
        
        <section id="advanced-search" class="full mb-quarter mobile-only">
          <a class="df-trigger" data-menu="#search-makes" href="javascript:void(0)">Make &amp; Model Search</a>
          <a class="df-trigger" data-menu="#pmt-search" href="javascript:void(0)">Search by Payment</a>
        </section>
       
          <?php $terms = get_terms( array(
    'taxonomy' => 'forsale_taxonomies',
    'hide_empty' => false,
    'order'     => 'ASC'
) );
          $i=0;

          foreach($terms as $term)
          {
            $i++;

         
?> 
         <!-- <ul><li><a itemprop="makesOffer" href="/for-sale/truck/">Trucks</a></li>
          <li><a itemprop="makesOffer" href="/for-sale/luxury-car/">Luxury Cars</a></li>
          <li><a itemprop="makesOffer" href="/for-sale/sports-car/">Sport Cars</a></li>
          <li><a itemprop="makesOffer" href="/for-sale/vans/">Vans</a></li> 
          <ul>
          <li><a itemprop="makesOffer" href="/for-sale/large-suv/">Large SUV</a></li>
          <li><a itemprop="makesOffer" href="/for-sale/small-suv/">Small SUV</a></li>
          <li><a itemprop="makesOffer" href="/for-sale/economy-car/">Economy Cars</a></li>
          <li><a itemprop="makesOffer" href="/for-sale/wow/">Less Than $20,000</a></li> 
        </ul> -->
          <ul>
          <?php if($term->name != 'Less Than $20,000') { ?>
          <li><a itemprop="makesOffer" href="<?php echo get_term_link($term->slug, 'forsale_taxonomies'); ?>"><?php echo $term->name; ?></a></li>
          <?php }  else { ?>
          <li><a itemprop="makesOffer" href="/for-sale/wow/">Less Than $20,000</a></li> 
          <?php } if($i==4) { ?>  <?php } $i=0; ?></ul>
          <?php } ?>
      </section>

      <?php echo do_shortcode('[model_popup]'); ?>

      <section id="advanced-search" class="full no-mobile">
        <!-- <a class="df-trigger" data-menu="#search-makes" href="javascript:void(0)">Make &amp; Model Search</a> -->
         <a class="df-trigger" data-pop="1">Make &amp; Model Search</a>
        <a class="df-trigger" data-menu="#pmt-search" href="javascript:void(0)">Search by Payment</a>
         

      </section>

  
            
      <section class="full mt-2">
        <div class="rotatable-text"><span class="rotating-text"></span></div>
      </section>
      <section class="full mb-3 mobile-only text-center">
        <a href="javascript:void(0)" data-modal="#tda-awesome-video" class="play-button modal-trigger">
                    <i class="icon-play-arrow"></i>
                </a>
      </section>
    </div>
  </section>
  <section class="lineup-wrap" id="suyc">
    <div class="wrapper-full">
		<div class="half">
			<div class="one-third">
				<a href="<?php echo get_term_link('Coupe', 'forsale_taxonomies'); ?>">
					<img src="<?php echo get_template_directory_uri();?>/assets/images/coupe.png" alt="Coupe in Houston TX" class="" title="Coupe in Houston TX">
					<h4>Coupe</h4>
				</a>
			</div>
			<div class="one-third">
				<a href="<?php echo get_term_link('Convertible', 'forsale_taxonomies'); ?>">
					<img src="<?php echo get_template_directory_uri();?>/assets/images/convertible.png" alt="Coupe in Houston TX" class="" title="Coupe in Houston TX">
					<h4>Convertible</h4>
				</a>
			</div>
			<div class="one-third">
				<a href="<?php echo get_term_link('Van', 'forsale_taxonomies'); ?>">
					<img src="<?php echo get_template_directory_uri();?>/assets/images/minivan.png" alt="Coupe in Houston TX" class="" title="Coupe in Houston TX">
					<h4>Van</h4>
				</a>
			</div>
		</div>


		<div class="half">
			<div class="one-third">
				<a href="<?php echo get_term_link('Sedan', 'forsale_taxonomies'); ?>">
					<img src="<?php echo get_template_directory_uri();?>/assets/images/sedan.png" alt="Coupe in Houston TX" class="" title="Coupe in Houston TX">
					<h4>Sedan</h4>
				</a>
			</div>
			<div class="one-third">
				<a href="<?php echo get_term_link('SUV', 'forsale_taxonomies'); ?>">
					<img src="<?php echo get_template_directory_uri();?>/assets/images/suv.png" alt="Coupe in Houston TX" class="" title="Coupe in Houston TX"
					><h4>SUV</h4>
				</a>
			</div>
			<div class="one-third">
				<a href="<?php echo get_term_link('Truck', 'forsale_taxonomies'); ?>">
					<img src="<?php echo get_template_directory_uri();?>/assets/images/truck.png" alt="Coupe in Houston TX" class="" title="Coupe in Houston TX">						
					<h4>Truck</h4>
				</a>
			</div>
		</div>
	</div>
  </section>
  
<section class="lineup-wrap finance" >
    <div class="wrapper-full">
		
		<div class="half">
			<div class="mod-google-map mod-google-map-responsive1">
				<div class="content">
					<?php echo do_shortcode('[pvn-google-map id="2"]'); ?>
					
				</div>
			</div>	
		</div>
		<div class="half">
			   <div class="formus">
             <center><h4>Value YOUR TRADE IN</h4></center>
             <center><span id="res"></span></center>
           <form class="form1" id="form1">
              <div class="wrapper-full">
                <div class="half">
                  <div class="form-group">
              
              VIN <input type="text" name="vin" class="form-control" id="vin" required/>
                  
                </div>
                <div class="form-group">
                  YEAR <input type="date" name="year" class="form-control" id="year" required/>
                  
                </div>
                <div class="form-group">
                  MAKE <input type="text" name="make" class="form-control" id="make" required/>
                  
                </div>
                <div class="form-group">
                  MODEL <input type="text" name="model" class="form-control" id="model" required/>
                  
                </div>
                <div class="form-group">
                  MILES <input type="number" name="mtlane" class="form-control" id="mtlane" required/>
                  
                </div>
                <div class="form-group">
                  PRICE <input type="number" name="price" class="form-control" id="price" required/>
                  
                 </div>
               </div>
               <div class="half">
                  <div class="form-group">
              
                FIRSTNAME <input type="text" name="firstname" class="form-control" id="firstname" required/>
                  
                </div>
                <div class="form-group">
                  LASTNAME <input type="text" name="lastname" class="form-control" id="lastname" required/>
                  
                </div>
                <div class="form-group">
                  EMAIL <input type="email" name="email" class="form-control" id="email" required/>
                  
                </div>
                <div class="form-group">
                  PHONE <input type="number" class="form-control" id="phone" name="phone" required/>
                  
                </div>
                <div class="form-group">
                  QUESTIONS <input type="text" name="questions" class="form-control" id="questions" required/>
                  
                </div>
                <div class="form-group">
                  CONTACTS <input type="number" name="contact" class="form-control" id="contact" required/>
                  
                 </div>
               </div>
              </div><br> 
               <button class="btn btn-info btninfo" id="btn1" type="button" >SUBMIT</button>
            </form>
         </div>
		</div>
	</div>
  </section>
  
  <section class="why" id="why">
    <div class="wrapper">
      <section class="full">
        <h2></h2>
      </section>
      <section class="full">
        <?php  echo  do_shortcode('[house_finence_sec]'); ?>
      </section>
      
    </div>

</div>
<?php get_footer(); ?>
<script async src="https://www.youtube.com/iframe_api"></script>
<script>

  jQuery('#suycUpload').submit(function (e) {
    jQuery('#btnSUYC').html('<i class="icon-settings i__spin"></i> Processing...');
    e.preventDefault();
    submitTrade(function (response) {
      var data = JSON.parse(response)
      analytics.track('Sell My Car', {
        action: 'Sell My Car Submit',
        category: 'Homepage',
        label: 'Sell My Car',
        year: data.year,
        make: data.make,
        model: data.model,
        vin: data.vin,
        color: data.color,
        price: data.expPrice,
        email: data.email,
        phone: data.cellPhone.replace(/[^0-9]/g, '')
      });
    });
  });

  jQuery('#locationSelect').on('change', function (e) {
    var location = $(this).val();
    jQuery('.location').removeClass('active');
    jQuery('.locationInfo').removeClass('active');
    jQuery('#' + location + 'Info').addClass('active');
    jQuery('#' + location).addClass('active');
    e.preventDefault();
  });

  jQuery('.location_selector').on('click', function (e) {
    var location = $(this).data('store');
    jQuery('.location').removeClass('active');
    jQuery('.locationInfo').removeClass('active');
    jQuery('#' + location + 'Info').addClass('active');
    jQuery('#' + location).addClass('active');
    jQuery('.modal').removeClass('is-visible');
    e.preventDefault();
  });

  jQuery('.car-selfie').click(function () {
    $('#up-selfie').click();
  });

  var selfies = [];

  jQuery('.df-trigger').on('click', function () {
    var menu = jQuery(this).data('menu');
    if (menu == '#finance-form') {
      var finance_form = jQuery('#tda-kiosk__finance-form').attr('src');
      if (finance_form == 'javascript:void(0)') {
        jQuery('#tda-kiosk__finance-form').attr('src', 'https://www.routeone.net/XRD/turnKeyOcaStart.do?&rteOneDmsId=F00TD2&dealerId=HZ7GJ&dealership_name=Texas+Direct+Auto&dealership_address=12053+Southwest+FWY+(Highway+59)&dealership_city=Stafford&dealership_state=TX&dealership_zip=77477&dealership_phone=(832)+241-0017&buyOrLease=1&dealership_email=sales@texasdirectauto.com&dealership_contact_name=Texas+Direct+Auto');
      }
    }
    jQuery(menu).addClass('active');
    jQuery('body').addClass('df-lock');
    jQuery('html').addClass('df-lock');
  });

  jQuery('.df-m-trigger').on('click', function () {
    var list = $(this).data('list');
    if (jQuery(list).css('display') == 'none') {
      jQuery('.df-makes-list').slideUp('slow');
      jQuery(list).slideToggle('slow');
    } else {
      jQuery(list).slideToggle('slow');
    }
  });

  jQuery('.df-close').on('click', function () {
    jQuery('.drop-form').removeClass('active');
    jQuery('body').removeClass('df-lock');
    jQuery('html').removeClass('df-lock');
  });
  jQuery('.notification__close').on('click', function () {
    jQuery('.wrapper').removeClass('notification__attached')
  });

</script>



