<?php
/**
 * Houston Direct Auto functions and definitions
 *
 */

include_once ('includes/location_post_type.php');
include_once ('includes/theme_options.php');
include_once ('includes/frontend.php');
include_once ('includes/auto_post_type.php');
include_once('includes/shortcodes/shortcode.php');
